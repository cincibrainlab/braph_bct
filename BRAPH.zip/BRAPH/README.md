# BRAPH
Brain Analysis using Graph Theory
